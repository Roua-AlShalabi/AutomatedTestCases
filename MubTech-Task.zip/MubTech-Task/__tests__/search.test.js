import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react-native';
import SearchScreen from '../src/components/SearchScreen';

const products = [
  { id: 1, name: 'iPhone 15' },
  { id: 2, name: 'Samsung Galaxy' },
  { id: 3, name: 'Pixel 9' },
];

describe('Search', () => {
  test('filters results as user types', () => {
    render(<SearchScreen products={products} />);

    fireEvent.changeText(screen.getByLabelText('search-input'), 'pixel');

    const list = screen.getByTestId('results-list');
    expect(list.props.data).toHaveLength(1);
    expect(screen.getByText('Pixel 9')).toBeTruthy();
  });

  test('shows "No results" when nothing matches', () => {
    render(<SearchScreen products={products} />);

    fireEvent.changeText(screen.getByLabelText('search-input'), 'nokia');
    expect(screen.getByTestId('no-results')).toHaveTextContent('No results');
  });
});