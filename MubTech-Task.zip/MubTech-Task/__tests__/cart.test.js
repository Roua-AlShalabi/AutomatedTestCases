import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react-native';
import { CartProvider } from '../src/components/CartProvider';
import { CartBadge } from '../src/components/CartBadge';
import { ProductListItem } from '../src/components/ProductListItem';

const wrap = (ui) => render(<CartProvider>{ui}</CartProvider>);

describe('Add to Cart', () => {
  test('adds an item and updates badge count', () => {
    wrap(<>
      <CartBadge />
      <ProductListItem product={{ id: 'p1', name: 'AirPods', price: 99 }} />
    </>);

    expect(screen.getByTestId('cart-count').props.children).toBe(0);

    fireEvent.press(screen.getByText('Add to cart'));
    expect(screen.getByTestId('cart-count').props.children).toBe(1);
  });

  test('adding same item increases quantity (no duplicates)', () => {
    wrap(<>
      <CartBadge />
      <ProductListItem product={{ id: 'p1', name: 'AirPods', price: 99 }} />
    </>);

    fireEvent.press(screen.getByText('Add to cart'));
    fireEvent.press(screen.getByText('Add to cart'));

   
    expect(screen.getByTestId('cart-count').props.children).toBe(2);
  });
});