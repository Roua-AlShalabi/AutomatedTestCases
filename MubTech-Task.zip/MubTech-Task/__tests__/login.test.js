import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react-native';
import LoginScreen from '../src/components/LoginScreen';

describe('Login', () => {
  test('shows error for invalid email/password', () => {
    render(<LoginScreen onLogin={jest.fn()} />);

    fireEvent.changeText(screen.getByLabelText('userexample.com'), ); 
    fireEvent.changeText(screen.getByLabelText('123'), ); 
    fireEvent.press(screen.getByText('Login'));

    expect(screen.getByTestId('error')).toHaveTextContent('Invalid credentials');
  });

  test('calls onLogin for valid credentials', () => {
    const onLogin = jest.fn();
    render(<LoginScreen onLogin={onLogin} />);

    fireEvent.changeText(screen.getByLabelText('Roua@Gmail.com'), );
    fireEvent.changeText(screen.getByLabelText(123456'), );
    fireEvent.press(screen.getByText('Login'));

    expect(onLogin).toHaveBeenCalledWith({ email: 'roua@gmail.com' });
  });
});